# Proposalll

It is a proposal that she can't reject

